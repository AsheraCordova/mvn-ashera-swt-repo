//start - license
/*******************************************************************************
 * Copyright (c) 2025 Ashera Cordova
 *
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *******************************************************************************/
//end - license
package com.roots.swtmap;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class MarkerManager {

    public static class Marker {
        public double lat, lon;
        public Image icon;
        public String title;
        public String snippet;
        public String type;
        public String id;

        int screenX, screenY;

        public Marker(String id, String type, double lat, double lon, Image icon, String title, String snippet) {
            this.lat = lat;
            this.lon = lon;
            this.icon = icon;
            this.title = title;
            this.snippet = snippet;
            this.type= type;
            this.id = id;
        }
    }

    private List<Marker> markers = new ArrayList<>();
    private Marker selectedMarker = null;

    private Composite popup;
    private Label popupLabel;

    private MapWidget map;

    public MarkerManager(MapWidget map) {
        this.map = map;

        createPopup();
        attachListeners();
    }

    // ? Add marker
    public void addMarker(String id, String type, double lat, double lon, Image icon, String title, String snippet) {
    	if (id == null) {
    		markers.add(new Marker(id, type, lat, lon, icon, title, snippet));	
    	} else {
    		java.util.Optional<Marker> marker = getMarkerById(id);
    		if (marker.isPresent()) {
    			marker.get().lat = lat;
    			marker.get().lon = lon;
    			marker.get().title = title;
    			marker.get().snippet = snippet;
    			marker.get().type = type;
    			marker.get().icon = icon;
    		} else{
    			markers.add(new Marker(id, type, lat, lon, icon, title, snippet));
    		}
    	}
    }

	public java.util.Optional<Marker> getMarkerById(String id) {
		java.util.Optional<Marker> marker = markers.stream().filter((m) -> id.equals(m.id)).findFirst();
		return marker;
	}
	
	
	public void renovetMarkerById(String id) {
		java.util.Optional<Marker> marker = getMarkerById(id);
		
		if (marker.isPresent()) {
			markers.remove(marker.get());
		}
	}

    // ? Create popup UI
    private void createPopup() {
        popup = new Composite(map, SWT.BORDER);
        popup.setVisible(false);

        popupLabel = new Label(popup, SWT.WRAP);
    }

    // ? Attach listeners
    private void attachListeners() {

    	map.addPaintListener(e -> {
    	    Point center = map.getCenterPosition();
    	    org.eclipse.swt.graphics.Rectangle bounds = map.getBounds();

    	    for (Marker m : markers) {
    	        Point world = map.computePosition(new MapWidget.PointD(m.lon, m.lat));

    	        int x = world.x - center.x + bounds.width / 2;
    	        int y = world.y - center.y + bounds.height / 2;

    	        m.screenX = x;
    	        m.screenY = y;

    	        switch (m.type) {
				case "image": {
	    	        if (m.icon == null) continue;

	    	        int w = m.icon.getBounds().width;
	    	        int h = m.icon.getBounds().height;

	    	        // Better visibility check
	    	        if (x + w/2 < 0 || x - w/2 > bounds.width ||
	    	            y < 0 || y - h > bounds.height) {
	    	            continue;
	    	        }

	    	        e.gc.drawImage(m.icon, x - w / 2, y - h);
					
					break;
				}
				case "circle": {
				    int x0 = x;
				    int y0 = y;

				    // Accuracy radius (you can store this in marker later)
				    int accuracyRadius = 30; // pixels (tweak or make dynamic)

				    // --- 1. Accuracy circle (transparent blue) ---
				    e.gc.setAlpha(60);
				    e.gc.setBackground(e.display.getSystemColor(SWT.COLOR_BLUE));
				    e.gc.fillOval(x0 - accuracyRadius, y0 - accuracyRadius,
				                  accuracyRadius * 2, accuracyRadius * 2);

				    // --- 2. Outer blue dot ---
				    int outerRadius = 10;
				    e.gc.setAlpha(255);
				    e.gc.setBackground(e.display.getSystemColor(SWT.COLOR_BLUE));
				    e.gc.fillOval(x0 - outerRadius, y0 - outerRadius,
				                  outerRadius * 2, outerRadius * 2);

				    // --- 3. Inner white dot ---
				    int innerRadius = 4;
				    e.gc.setBackground(e.display.getSystemColor(SWT.COLOR_WHITE));
				    e.gc.fillOval(x0 - innerRadius, y0 - innerRadius,
				                  innerRadius * 2, innerRadius * 2);

				    break;
				}
				default:
					break;
				}
    	    }
    	});

        // Click detection
    	map.addListener(SWT.MouseDown, e -> {

    	    for (Marker m : markers) {

    	        if (m.icon == null || (m.title == null && m.snippet == null)) continue;

    	        int w = m.icon.getBounds().width;
    	        int h = m.icon.getBounds().height;

    	        int left   = m.screenX - w / 2;
    	        int right  = m.screenX + w / 2;
    	        int top    = m.screenY - h;
    	        int bottom = m.screenY;

    	        // ✅ Bounding box hit test (fast, accurate)
    	        if (e.x >= left && e.x <= right &&
    	            e.y >= top  && e.y <= bottom) {

    	            showPopup(m);
    	            return;
    	        }
    	    }

    	    hidePopup();
    	});

        // Hide popup on move
        map.addListener(SWT.MouseMove, e -> {
            // optional: keep or remove
        });
    }

    // ? Show popup
    private void showPopup(Marker m) {
        selectedMarker = m;

        String desc = m.title != null ? m.title : "";
        
        if (m.snippet != null) {
        	desc += (m.title != null ? "\n" : "") + m.snippet;
        }
		popupLabel.setText(desc);
        popupLabel.pack();
        popup.pack();

        int x = m.screenX - popup.getSize().x / 2;
        int y = m.screenY - 60;

        popup.setLocation(x, y);
        popup.setVisible(true);
    }

    private void hidePopup() {
        selectedMarker = null;
        popup.setVisible(false);
    }
}