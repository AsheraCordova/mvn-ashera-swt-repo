//start - license
/*******************************************************************************
 * Copyright (c) 2025 Ashera Cordova
 *
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *******************************************************************************/
//end - license
package com.ashera.spatialkit;
//start - imports

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

import r.android.content.Context;


import org.eclipse.swt.widgets.*;
import org.eclipse.swt.graphics.*;
import androidx.core.view.*;
import static com.ashera.common.DisposeUtil.*;

import r.android.os.Build;
import r.android.view.View;
import r.android.text.*;

import com.ashera.core.IFragment;
import com.ashera.converter.*;

import r.android.annotation.SuppressLint;

import com.ashera.layout.*;
import com.ashera.plugin.*;
import com.ashera.widget.bus.*;
import com.ashera.widget.*;
import com.ashera.widget.bus.Event.*;
import com.ashera.widget.IWidgetLifeCycleListener.EventId;
import com.ashera.widget.IWidgetLifeCycleListener.EventId.*;


import static com.ashera.widget.IWidget.*;
//end - imports
@SuppressLint("NewApi")
public class MapViewImpl extends BaseWidget {
	//start - body
	public final static String LOCAL_NAME = "org.maplibre.android.maps.MapView"; 
	public final static String GROUP_NAME = "org.maplibre.android.maps.MapView";

	protected com.roots.swtmap.MapWidget mapWidget;
	protected org.maplibre.android.maps.MapView measurableView;	
	
	
	@Override
	public void loadAttributes(String attributeName) {
		ViewImpl.register(attributeName);


		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("maplibre_cameraTargetLat").withType("float"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("maplibre_cameraTargetLng").withType("float"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("maplibre_cameraZoom").withType("float"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("showMarkerForTarget").withType("boolean"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("targetLocationMarkerTitle").withType("resourcestring"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("targetLocationMarkerSnippet").withType("resourcestring"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("targetLocationMarkerIcon").withType("drawable"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("showsUserLocation").withType("boolean"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("addMarker").withType("object"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("removeMarker").withType("string"));
		WidgetFactory.registerAttribute(localName, new WidgetAttribute.Builder().withName("onMapClick").withType("string"));
	}
	
	public MapViewImpl() {
		super(GROUP_NAME, LOCAL_NAME);
	}
	public  MapViewImpl(String localname) {
		super(GROUP_NAME, localname);
	}
	public  MapViewImpl(String groupName, String localname) {
		super(groupName, localname);
	}

		
	public class MapViewExt extends org.maplibre.android.maps.MapView implements ILifeCycleDecorator, com.ashera.widget.IMaxDimension{
		private MeasureEvent measureFinished = new MeasureEvent();
		private OnLayoutEvent onLayoutEvent = new OnLayoutEvent();
		private List<IWidget> overlays;
		public IWidget getWidget() {
			return MapViewImpl.this;
		}
		private int mMaxWidth = -1;
		private int mMaxHeight = -1;
		@Override
		public void setMaxWidth(int width) {
			mMaxWidth = width;
		}
		@Override
		public void setMaxHeight(int height) {
			mMaxHeight = height;
		}
		@Override
		public int getMaxWidth() {
			return mMaxWidth;
		}
		@Override
		public int getMaxHeight() {
			return mMaxHeight;
		}

		public MapViewExt() {
			super();
			
		}
		
		@Override
		public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

			if(mMaxWidth > 0) {
	        	widthMeasureSpec = MeasureSpec.makeMeasureSpec(mMaxWidth, MeasureSpec.AT_MOST);
	        }
	        if(mMaxHeight > 0) {
	            heightMeasureSpec = MeasureSpec.makeMeasureSpec(mMaxHeight, MeasureSpec.AT_MOST);

	        }

	        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			IWidgetLifeCycleListener listener = (IWidgetLifeCycleListener) getListener();
			if (listener != null) {
			    measureFinished.setWidth(getMeasuredWidth());
			    measureFinished.setHeight(getMeasuredHeight());
				listener.eventOccurred(EventId.measureFinished, measureFinished);
			}
		}
		
		@Override
		protected void onLayout(boolean changed, int l, int t, int r, int b) {
			super.onLayout(changed, l, t, r, b);
			ViewImpl.setDrawableBounds(MapViewImpl.this, l, t, r, b);
			if (!isOverlay()) {
			ViewImpl.nativeMakeFrame(asNativeWidget(), l, t, r, b);
			}
			replayBufferedEvents();
	        ViewImpl.redrawDrawables(MapViewImpl.this);
	        overlays = ViewImpl.drawOverlay(MapViewImpl.this, overlays);
			
			IWidgetLifeCycleListener listener = (IWidgetLifeCycleListener) getListener();
			if (listener != null) {
				onLayoutEvent.setB(b);
				onLayoutEvent.setL(l);
				onLayoutEvent.setR(r);
				onLayoutEvent.setT(t);
				onLayoutEvent.setChanged(changed);
				listener.eventOccurred(EventId.onLayout, onLayoutEvent);
			}
			
			if (isInvalidateOnFrameChange() && isInitialised()) {
				MapViewImpl.this.invalidate();
			}
		}	
		
		@Override
		public void execute(String method, Object... canvas) {
			
		}

		public void updateMeasuredDimension(int width, int height) {
			setMeasuredDimension(width, height);
		}


		@Override
		public ILifeCycleDecorator newInstance(IWidget widget) {
			throw new UnsupportedOperationException();
		}

		@Override
		public void setAttribute(WidgetAttribute widgetAttribute,
				String strValue, Object objValue) {
			throw new UnsupportedOperationException();
		}		
		

		@Override
		public List<String> getMethods() {
			throw new UnsupportedOperationException();
		}
		
		@Override
		public void initialized() {
			throw new UnsupportedOperationException();
		}
		
        @Override
        public Object getAttribute(WidgetAttribute widgetAttribute) {
            throw new UnsupportedOperationException();
        }
        @Override
        public void drawableStateChanged() {
        	super.drawableStateChanged();
        	if (!isWidgetDisposed()) {
        		ViewImpl.drawableStateChanged(MapViewImpl.this);
        	}
        }
        private Map<String, IWidget> templates;
    	@Override
    	public r.android.view.View inflateView(java.lang.String layout) {
    		if (templates == null) {
    			templates = new java.util.HashMap<String, IWidget>();
    		}
    		IWidget template = templates.get(layout);
    		if (template == null) {
    			template = (IWidget) quickConvert(layout, "template");
    			templates.put(layout, template);
    		}
    		
    		IWidget widget = template.loadLazyWidgets(MapViewImpl.this.getParent());
			return (View) widget.asWidget();
    	}   
        
    	@Override
		public void remeasure() {
    		if (getFragment() != null) {
    			getFragment().remeasure();
    		}
		}
    	
        @Override
		public void removeFromParent() {
        	MapViewImpl.this.getParent().remove(MapViewImpl.this);
		}
        @Override
        public void getLocationOnScreen(int[] appScreenLocation) {
        	org.eclipse.swt.widgets.Control control = (org.eclipse.swt.widgets.Control) asNativeWidget();
			appScreenLocation[0] = control.toDisplay(0, 0).x;
        	appScreenLocation[1] = control.toDisplay(0, 0).y;
        }
        @Override
        public void getWindowVisibleDisplayFrame(r.android.graphics.Rect displayFrame){
        	org.eclipse.swt.widgets.Shell shell = ((org.eclipse.swt.widgets.Control)asNativeWidget()).getShell();
        	displayFrame.left = shell.toDisplay(0, 0).x ;
			displayFrame.top = shell.getShell().toDisplay(0, 0).y ;
        	displayFrame.bottom = displayFrame.top + shell.getClientArea().height;
        	displayFrame.right = displayFrame.left + shell.getBounds().width;
        	
        }
        @Override
		public void offsetTopAndBottom(int offset) {
			super.offsetTopAndBottom(offset);
			ViewImpl.nativeMakeFrame(asNativeWidget(), getLeft(), getTop(), getRight(), getBottom());
		}
		@Override
		public void offsetLeftAndRight(int offset) {
			super.offsetLeftAndRight(offset);
			ViewImpl.nativeMakeFrame(asNativeWidget(), getLeft(), getTop(), getRight(), getBottom());
		}
		@Override
		public void setMyAttribute(String name, Object value) {
			if (name.equals("state0")) {
				setState0(value);
				return;
			}
			if (name.equals("state1")) {
				setState1(value);
				return;
			}
			if (name.equals("state2")) {
				setState2(value);
				return;
			}
			if (name.equals("state3")) {
				setState3(value);
				return;
			}
			if (name.equals("state4")) {
				setState4(value);
				return;
			}
			MapViewImpl.this.setAttribute(name, value, !(value instanceof String));
		}
        @Override
        public void setVisibility(int visibility) {
            super.setVisibility(visibility);
            org.eclipse.swt.widgets.Control control = ((org.eclipse.swt.widgets.Control)asNativeWidget());
            if (!control.isDisposed()) {
            	control.setVisible(View.VISIBLE == visibility);
            }
            
        }
        
    	public void setState0(Object value) {
    		ViewImpl.setState(MapViewImpl.this, 0, value);
    	}
    	public void setState1(Object value) {
    		ViewImpl.setState(MapViewImpl.this, 1, value);
    	}
    	public void setState2(Object value) {
    		ViewImpl.setState(MapViewImpl.this, 2, value);
    	}
    	public void setState3(Object value) {
    		ViewImpl.setState(MapViewImpl.this, 3, value);
    	}
    	public void setState4(Object value) {
    		ViewImpl.setState(MapViewImpl.this, 4, value);
    	}
        	public void state0() {
        		ViewImpl.state(MapViewImpl.this, 0);
        	}
        	public void state1() {
        		ViewImpl.state(MapViewImpl.this, 1);
        	}
        	public void state2() {
        		ViewImpl.state(MapViewImpl.this, 2);
        	}
        	public void state3() {
        		ViewImpl.state(MapViewImpl.this, 3);
        	}
        	public void state4() {
        		ViewImpl.state(MapViewImpl.this, 4);
        	}
                        
        public void stateYes() {
        	ViewImpl.stateYes(MapViewImpl.this);
        	
        }
        
        public void stateNo() {
        	ViewImpl.stateNo(MapViewImpl.this);
        }
     
	
	}	@Override
	public Class getViewClass() {
		return MapViewExt.class;
	}

	@Override
	public IWidget newInstance() {
		return new MapViewImpl(groupName, localName);
	}
	
	@SuppressLint("NewApi")
	@Override
	public void create(IFragment fragment, Map<String, Object> params) {
		super.create(fragment, params);
		measurableView = new MapViewExt();
		nativeCreate(params);	
		ViewImpl.registerCommandConveter(this);
	}

	@Override
	@SuppressLint("NewApi")
	public void setAttribute(WidgetAttribute key, String strValue, Object objValue, ILifeCycleDecorator decorator) {
		Object nativeWidget = asNativeWidget();
		ViewImpl.setAttribute(this,  key, strValue, objValue, decorator);
		
		switch (key.getAttributeName()) {
			case "maplibre_cameraTargetLat": {
				


		setCameraTargetLat(objValue);



			}
			break;
			case "maplibre_cameraTargetLng": {
				


		setCameraTargetLng(objValue);



			}
			break;
			case "maplibre_cameraZoom": {
				


		setCameraZoom(objValue);



			}
			break;
			case "showMarkerForTarget": {
				


		showMarkerForTarget(objValue);



			}
			break;
			case "targetLocationMarkerTitle": {
				


		setTargetLocationMarkerTitle(objValue);



			}
			break;
			case "targetLocationMarkerSnippet": {
				


		setTargetLocationMarkerSnippet(objValue);



			}
			break;
			case "targetLocationMarkerIcon": {
				


		setTargetLocationMarkerIcon(objValue);



			}
			break;
			case "showsUserLocation": {
				


		setShowsUserLocation(objValue);



			}
			break;
			case "addMarker": {
				
		if (objValue instanceof Map) {
			Map<String, Object> data = ((Map<String, Object>) objValue);
		Object id = quickConvert(data.get("id"), "string");
		Object latitude = quickConvert(data.get("latitude"), "float");
		Object longitude = quickConvert(data.get("longitude"), "float");
		Object title = quickConvert(data.get("title"), "resourcestring");
		Object snippet = quickConvert(data.get("snippet"), "resourcestring");
		Object icon = quickConvert(data.get("icon"), "drawable");


		 addMarker(id, latitude, longitude, title, snippet, icon);


}
if (objValue instanceof java.util.List) {
	java.util.List<Object> list = (java.util.List<Object>) objValue;
	for (Object object : list) {
		Map<String, Object> data = PluginInvoker.getMap(object);
		Object id = quickConvert(data.get("id"), "string");
		Object latitude = quickConvert(data.get("latitude"), "float");
		Object longitude = quickConvert(data.get("longitude"), "float");
		Object title = quickConvert(data.get("title"), "resourcestring");
		Object snippet = quickConvert(data.get("snippet"), "resourcestring");
		Object icon = quickConvert(data.get("icon"), "drawable");


		 addMarker(id, latitude, longitude, title, snippet, icon);


	}
}
			}
			break;
			case "removeMarker": {
				


		removeMarker(objValue);



			}
			break;
			case "onMapClick": {
				


		setOnMapClickListener(strValue, objValue);



			}
			break;
		default:
			break;
		}
		
	}
	
	@Override
	@SuppressLint("NewApi")
	public Object getAttribute(WidgetAttribute key, ILifeCycleDecorator decorator) {
		Object nativeWidget = asNativeWidget();
		Object attributeValue = ViewImpl.getAttribute(this, nativeWidget, key, decorator);
		if (attributeValue != null) {
			return attributeValue;
		}
		switch (key.getAttributeName()) {
		}
		
		return null;
	}
	
	@Override
	public Object asWidget() {
		return measurableView;
	}

	
	@SuppressLint("NewApi")
private static class OnMapClickListener implements MapLibreMap.OnMapClickListener, com.ashera.widget.IListener{
private IWidget w; private View view; private String strValue; private String action;
public String getAction() {return action;}
public OnMapClickListener(IWidget w, String strValue)  {
this.w = w; this.strValue = strValue;
}
public OnMapClickListener(IWidget w, String strValue, String action)  {
this.w = w; this.strValue = strValue;this.action=action;
}
public boolean onMapClick(LatLng point){
    boolean result = true;
    
	if (action == null || action.equals("onMapClick")) {
		// populate the data from ui to pojo
		w.syncModelFromUiToPojo("onMapClick");
	    java.util.Map<String, Object> obj = getOnMapClickEventObj(point);
	    String commandName =  (String) obj.get(EventExpressionParser.KEY_COMMAND_NAME);
	    
	    // execute command based on command type
	    String commandType = (String)obj.get(EventExpressionParser.KEY_COMMAND_TYPE);
		switch (commandType) {
		case "+":
		    if (EventCommandFactory.hasCommand(commandName)) {
		    	 Object commandResult = EventCommandFactory.getCommand(commandName).executeCommand(w, obj, point);
		    	 if (commandResult != null) {
		    		 result = (boolean) commandResult;
		    	 }
		    }

			break;
		default:
			break;
		}
		
		if (obj.containsKey("refreshUiFromModel")) {
			Object widgets = obj.remove("refreshUiFromModel");
			com.ashera.layout.ViewImpl.refreshUiFromModel(w, widgets, true);
		}
		if (w.getModelUiToPojoEventIds() != null) {
			com.ashera.layout.ViewImpl.refreshUiFromModel(w, w.getModelUiToPojoEventIds(), true);
		}
		if (strValue != null && !strValue.isEmpty() && !strValue.trim().startsWith("+")) {
		    com.ashera.core.IActivity activity = (com.ashera.core.IActivity)w.getFragment().getRootActivity();
		    if (activity != null) {
		    	activity.sendEventMessage(obj);
		    }
		}
	}
    return result;
}//#####

public java.util.Map<String, Object> getOnMapClickEventObj(LatLng point) {
	java.util.Map<String, Object> obj = com.ashera.widget.PluginInvoker.getJSONCompatMap();
    obj.put("action", "action");
    obj.put("eventType", "mapclick");
    obj.put("fragmentId", w.getFragment().getFragmentId());
    obj.put("actionUrl", w.getFragment().getActionUrl());
    obj.put("namespace", w.getFragment().getNamespace());
    
    if (w.getComponentId() != null) {
    	obj.put("componentId", w.getComponentId());
    }
    
    PluginInvoker.putJSONSafeObjectIntoMap(obj, "id", w.getId());
     
        MapViewImpl.addEventInfo(obj, point);
    
    // parse event info into the map
    EventExpressionParser.parseEventExpression(strValue, obj);
    
    // update model data into map
    w.updateModelToEventMap(obj, "onMapClick", (String)obj.get(EventExpressionParser.KEY_EVENT_ARGS));
    return obj;
}
}

	
	    @Override
	    public Object asNativeWidget() {
	        return mapWidget;
	    }
	@Override
	public void setId(String id){
		if (id != null && !id.equals("")){
			super.setId(id);
			measurableView.setId((int) quickConvert(id, "id"));
		}
	}
	
    @Override
    public void setVisible(boolean b) {
        ((View)asWidget()).setVisibility(b ? View.VISIBLE : View.GONE);
    }
	public int getStyle(String key, int initStyle, Map<String, Object> params, IFragment fragment) {
		if (params == null) {
    		return initStyle;
    	}
    	Object style = params.get(key);
		if (style == null) {
			return initStyle;
		}
		int convertFrom = (int) ConverterFactory.get("swtbitflag").convertFrom(style.toString(), null, fragment);
		return convertFrom;
	}
	
	public int getStyle(Map<String, Object> params, IFragment fragment) {
		return getStyle("swtStyle", org.eclipse.swt.SWT.NONE, params, fragment);
	}
	
	public int getStyle(int initStyle, Map<String, Object> params, IFragment fragment) {
		return getStyle("swtStyle", initStyle, params, fragment);
	}
 
    @Override
    public void requestLayout() {
    	if (isInitialised()) {
    		ViewImpl.requestLayout(this, asNativeWidget());
    		
    	}
    }
    
    @Override
    public void invalidate() {
    	if (isInitialised()) {
			ViewImpl.invalidate(this, asNativeWidget());

    	}
    }
	public boolean isWidgetDisposed() {
		return mapWidget.isDisposed();
	}

	
		//end - body

	private com.roots.swtmap.MarkerManager markerManager;
	private void nativeCreate(Map<String, Object> params) {
		mapWidget = new com.roots.swtmap.MapWidget((org.eclipse.swt.widgets.Composite)ViewImpl.getParent(this), getStyle(params, fragment));
		this.markerManager = new com.roots.swtmap.MarkerManager(mapWidget);		
	}
	
	private float lat;
	private float lng;
	private Object targetLocationMarkerIcon;
	private String targetLocationMarkerSnippet;
	private String targetLocationMarkerTitle;
	private Boolean showMarkerForTarget;
	
	private void addMarker(Object id, Object latitude, Object longitude, Object title, Object snippet, Object iconDrawable) {
		addMyMarker((String) id, "image", latitude, longitude, title, snippet, iconDrawable);
	}

	private void addMyMarker(String id, String type, Object latitude, Object longitude, Object title, Object snippet,
			Object iconDrawable) {
		Image icon = null;
		markerManager.renovetMarkerById(id);
		if (showMarkerForTarget != null && showMarkerForTarget) {
			if (iconDrawable instanceof r.android.graphics.drawable.Drawable) {
				icon = (Image) ((r.android.graphics.drawable.Drawable)iconDrawable).getDrawable();
			}
		}
		
		if (icon == null && type.equals("image")) {
			java.io.InputStream stream = MapViewImpl.class.getClassLoader().getResourceAsStream("www/res-swt/drawable/icon_location.png");
			icon = new Image(Display.getDefault(), stream);
		}
		markerManager.addMarker(id, type, (float) latitude, (float) longitude, icon, (String) title, (String) snippet);
		mapWidget.redraw();
	}

	private void setTargetLocationMarkerIcon(Object objValue) {
		targetLocationMarkerIcon = objValue;
		
		if (isInitialised()) {
			java.util.Optional<com.roots.swtmap.MarkerManager.Marker> marker = markerManager.getMarkerById("targetLocationMarker");
			
			if (marker.isPresent()) {
				if (targetLocationMarkerIcon instanceof r.android.graphics.drawable.Drawable) {
					Image icon = (Image) ((r.android.graphics.drawable.Drawable)targetLocationMarkerIcon).getDrawable();
					marker.get().icon = icon;
					mapWidget.redraw();
				}
			}
		}
	}

	private void setTargetLocationMarkerSnippet(Object objValue) {
		targetLocationMarkerSnippet = (String) objValue;
		
		if (isInitialised()) {
			java.util.Optional<com.roots.swtmap.MarkerManager.Marker> marker = markerManager.getMarkerById("targetLocationMarker");
			
			if (marker.isPresent()) {
				marker.get().snippet = targetLocationMarkerSnippet;
				mapWidget.redraw();
			}
		}
	}

	private void setTargetLocationMarkerTitle(Object objValue) {
		targetLocationMarkerTitle = (String) objValue;
		
		if (isInitialised()) {
			java.util.Optional<com.roots.swtmap.MarkerManager.Marker> marker = markerManager.getMarkerById("targetLocationMarker");
			
			if (marker.isPresent()) {
				marker.get().title = targetLocationMarkerTitle;
				mapWidget.redraw();
			}
		}
	}

	private void showMarkerForTarget(Object objValue) {
		showMarkerForTarget = (boolean) objValue;
		
		if (isInitialised()) {
			showMarkerForTargetLocation();
			mapWidget.redraw();
		}
	}

	private void setCameraZoom(Object objValue) {
		mapWidget.setZoom(((Float) objValue).intValue());
		
		if (isInitialised()) {
			mapWidget.redraw();
		}
	}

	private void setCameraTargetLng(Object objValue) {
		lng = (float) objValue; 
		
		if (isInitialised()) {
			java.util.Optional<com.roots.swtmap.MarkerManager.Marker> marker = markerManager.getMarkerById("targetLocationMarker");
			
			if (marker.isPresent()) {
				marker.get().lon = lng;
				mapWidget.redraw();
			}
		}
	}

	private void setCameraTargetLat(Object objValue) {
		lat = (float) objValue;
		
		if (isInitialised()) {
			java.util.Optional<com.roots.swtmap.MarkerManager.Marker> marker = markerManager.getMarkerById("targetLocationMarker");
			
			if (marker.isPresent()) {
				marker.get().lat = lat;
			}
		}
	}
	
	@Override
	public void initialized() {
		super.initialized();
		
		Point center = mapWidget.computePosition(new com.roots.swtmap.MapWidget.PointD(lng, lat));
		new r.android.os.Handler().post(new Runnable() {

			@Override
			public void run() {
				mapWidget.setCenterPosition(center);
			}
			
		});
		
		
		showMarkerForTargetLocation();
	}
	
	
	private void removeMarker(Object id) {
		markerManager.renovetMarkerById((String) id);	
		mapWidget.redraw();
	}

	public void showMarkerForTargetLocation() {
		markerManager.renovetMarkerById("targetLocationMarker");
		if (showMarkerForTarget != null && showMarkerForTarget) {
			addMarker("targetLocationMarker", lat, lng, targetLocationMarkerTitle, targetLocationMarkerSnippet, targetLocationMarkerIcon);
		}
	}
	
	private com.ashera.widget.bus.EventBusHandler locationEventBusHandler;
	private void setShowsUserLocation(Object objValue) {
		if ((boolean) objValue) {
			locationEventBusHandler = new com.ashera.widget.bus.EventBusHandler("compass") {
				@Override
				protected void doPerform(Object payload) {
					Map<String, Float> compassmap = (Map<String, Float>) payload;
					float latitude = compassmap.get("latitude");
					float longitude = compassmap.get("longitude");
	
					if (latitude != 0 && longitude != 0) {
						addMyMarker("userlocation", "circle", latitude, longitude, null, null, null);
					}
				}
			};
			fragment.getEventBus().on("compass", locationEventBusHandler);
		} else {
			if (locationEventBusHandler != null) {
				fragment.getEventBus().off(locationEventBusHandler);
			}
			
			markerManager.renovetMarkerById("userlocation");
			if (isInitialised()) {
				mapWidget.redraw();
			}
		}

	}
	//start - codecopy
	final static class  MapLibreMap {
		interface OnMapClickListener {
			public boolean onMapClick(LatLng point);
		}
	}
	
	class LatLng {
		private double lat;
		private double lng;
		public LatLng(double lat, double lng) {
			this.lat = lat;
			this.lng = lng;
		}
		public double getLatitude() {
			return lat;
		}
		public double getLongitude() {
			return lng;
		}
		
	}
	private MapLibreMap.OnMapClickListener onMapClickListener;
	private boolean addedOnMapClickListener;
	private void setOnMapClickListener(String strValue, Object objValue) {
		if (objValue instanceof String) {
			onMapClickListener = new OnMapClickListener(this, strValue);
		} else {
			onMapClickListener = (MapLibreMap.OnMapClickListener) objValue;
		}
		
		setOnMapClickListener();
	}
	
	
	public static void addEventInfo(Map<String, Object> obj, LatLng point) {
		obj.put("latitude", point.getLatitude());
		obj.put("longitude", point.getLongitude());
	}
	//end - codecopy
	public void setOnMapClickListener() {
		if (!addedOnMapClickListener) {
			addedOnMapClickListener = true;
			mapWidget.addMouseListener(new org.eclipse.swt.events.MouseAdapter() {
	            @Override
	            public void mouseDown(org.eclipse.swt.events.MouseEvent e) {
	                if (e.button == 1) { 
	                     if (onMapClickListener != null) {
		                    com.roots.swtmap.MapWidget.PointD pointD = mapWidget.getLongitudeLatitude(mapWidget.getCursorPosition());
		                    onMapClickListener.onMapClick(new LatLng(pointD.x, pointD.y));
	                     }
	                }
	            }
			});
		}
	}

}
