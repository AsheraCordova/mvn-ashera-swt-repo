//start - license
/*******************************************************************************
 * Copyright (c) 2025 Ashera Cordova
 *
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *******************************************************************************/
//end - license
package com.ashera.spatialkit;

import java.util.Map;

import com.ashera.core.IFragment;
import com.ashera.core.IFragmentManager;
import com.ashera.widget.IWidget;

public class CompassManager implements com.ashera.core.IFragmentManager {
	private float heading, oldHeading, longitude, latitude, altitude, magneticDeclination, trueHeading, oldTrueHeading;
	private IFragment fragment;
	private boolean stopListeners;
	private boolean polling;

	@Override
	public void onCreate(com.ashera.core.IFragment fragment, Object... args) {
		this.fragment = fragment;
		heading = oldHeading = longitude = latitude = altitude = magneticDeclination = trueHeading = 0;
	}

	@Override
	public void onResume(com.ashera.core.IFragment fragment) {
		if (!stopListeners) {
			startPolling();
		}
	}

	@Override
	public void onPause(com.ashera.core.IFragment fragment) {
		removeListeners();
	}

	private void removeListeners() {
		if (!stopListeners) {
			stopPolling();
		}
	}

	private void removeAndStopListeners() {
		removeListeners();
		stopListeners = true;
	}

	private void updateHeading() {
		oldHeading = heading;
		oldTrueHeading = trueHeading;

		if (latitude != 0 && longitude != 0) {
			magneticDeclination = CompassHelper.calculateMagneticDeclination(latitude, longitude, altitude);
			trueHeading = magneticDeclination + heading;
		}
		trueHeading = smoothHeading(trueHeading, oldTrueHeading);

		publishResult();

	}

	private float smoothHeading(float newHeading, float currentHeading) {
		newHeading = adjustForWrap(newHeading, currentHeading);

		float diff = Math.abs(newHeading - currentHeading);
		if (diff > 180)
			diff = 360 - diff;

		float alpha;

		if (diff > 30) {
			alpha = 0.5f; // fast response
		} else if (diff > 10) {
			alpha = 0.25f;
		} else {
			alpha = 0.08f; // heavy smoothing
		}

		float smoothed = currentHeading + alpha * (newHeading - currentHeading);

		if (smoothed < 0)
			smoothed += 360;
		if (smoothed >= 360)
			smoothed -= 360;

		currentHeading = smoothed;
		return smoothed;
	}

	private float adjustForWrap(float newHeading, float currentHeading) {
		float diff = newHeading - currentHeading;

		if (diff > 180) {
			newHeading -= 360;
		} else if (diff < -180) {
			newHeading += 360;
		}

		return newHeading;
	}

	// keep last values
	private Float lastHeading, lastTrueHeading, lastLatitude, lastLongitude;
	private Float lastAltitude, lastMagneticDeclination;

	// thresholds (tune these)
	private static final float HEADING_THRESHOLD = 0.5f;
	private static final float LOCATION_THRESHOLD = 0.00001f;
	private static final float ALTITUDE_THRESHOLD = 0.5f;

	private boolean hasChanged(Float oldVal, float newVal, float threshold) {
	    return oldVal == null || Math.abs(oldVal - newVal) > threshold;
	}

	private void publishResult() {
	    boolean changed = false;

	    if (hasChanged(lastHeading, heading, HEADING_THRESHOLD)) changed = true;
	    if (hasChanged(lastTrueHeading, trueHeading, HEADING_THRESHOLD)) changed = true;
	    if (hasChanged(lastLatitude, latitude, LOCATION_THRESHOLD)) changed = true;
	    if (hasChanged(lastLongitude, longitude, LOCATION_THRESHOLD)) changed = true;
	    if (hasChanged(lastAltitude, altitude, ALTITUDE_THRESHOLD)) changed = true;
	    if (hasChanged(lastMagneticDeclination, magneticDeclination, HEADING_THRESHOLD)) changed = true;

	    if (!changed) {
	        return; // skip publish
	    }

	    // update last values
	    lastHeading = heading;
	    lastTrueHeading = trueHeading;
	    lastLatitude = latitude;
	    lastLongitude = longitude;
	    lastAltitude = altitude;
	    lastMagneticDeclination = magneticDeclination;

	    Map<String, Float> compassmap = new java.util.HashMap<>();
	    compassmap.put("heading", heading);
	    compassmap.put("trueHeading", trueHeading);
	    compassmap.put("oldHeading", oldHeading);
	    compassmap.put("oldTrueHeading", oldTrueHeading);
	    compassmap.put("latitude", latitude);
	    compassmap.put("longitude", longitude);
	    compassmap.put("altitude", altitude);
	    compassmap.put("magneticDeclination", magneticDeclination);

	    fragment.getEventBus().notifyObservers("compass", compassmap);
	}

	private void startPolling() {
		polling = true;

		poll();
	}

	private void stopPolling() {
		polling = false;
	}

	private void poll() {
		if (!polling)
			return;
		IWidget compassWidget = fragment.getRootWidget().findWidgetById("@+id/hiddenBrowser");
		if (compassWidget != null) {
			org.eclipse.swt.browser.Browser browser = (org.eclipse.swt.browser.Browser) compassWidget.asNativeWidget();
			Object result = browser.evaluate("return window.compassData ? "
					+ "[window.compassData.heading, window.compassData.lat, window.compassData.lng] : null;");
			if (result instanceof Object[]) {
				Object[] arr = (Object[]) result;

				heading = ((Number) arr[0]).floatValue();
				latitude = ((Number) arr[1]).floatValue();
				longitude = ((Number) arr[2]).floatValue();
				updateHeading();
			}

			org.eclipse.swt.widgets.Display.getDefault().timerExec(100, this::poll);
		}
	}

	@Override
	public void onRequestPermissionsResult(IFragment fragment, int requestCode, String[] permissions,
			int[] grantResults) {

	}

	@Override
	public void onAttach(IFragment fragment) {

	}

	@Override
	public void onDetach(IFragment fragment) {

	}

	@Override
	public void onDestroy(IFragment fragment) {

	}

	@Override
	public IFragmentManager newInstance() {
		return new CompassManager();
	}

	@Override
	public void sendEvent(String action, Map<String, String> extraData) {
		switch (action) {

		case "onDestinationReached":
			removeAndStopListeners();
			break;

		default:
			break;
		}
	}

	@Override
	public void onSaveInstanceState(IFragment fragment, Object... args) {
	}

	@Override
	public void onStart(IFragment fragment) {
	}

	@Override
	public void onStop(IFragment fragment) {
	}

}
