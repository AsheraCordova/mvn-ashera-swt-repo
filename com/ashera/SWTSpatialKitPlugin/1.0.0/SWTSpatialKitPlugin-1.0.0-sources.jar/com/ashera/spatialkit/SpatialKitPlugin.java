//start - license
/*******************************************************************************
 * Copyright (c) 2025 Ashera Cordova
 *
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *******************************************************************************/
//end - license
package com.ashera.spatialkit;

import com.ashera.widget.WidgetFactory;

public class SpatialKitPlugin  {
    public static void initPlugin() {
    	//start - widgets
        com.ashera.widget.WidgetFactory.registerAttributableFor("View", new com.ashera.spatialkit.CompassViewImpl());
        WidgetFactory.register(new com.ashera.spatialkit.MapViewImpl());
        //end - widgets
        com.ashera.core.FragmentManagerFactory.registerManager("compass", new CompassManager());
        com.ashera.core.FragmentManagerFactory.registerManager("map", new CompassManager());
    }
}
